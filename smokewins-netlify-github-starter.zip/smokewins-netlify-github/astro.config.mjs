import { defineConfig } from 'astro/config';
export default defineConfig({
  // Set after adding your real domain, e.g. 'https://smokewins.com'
  site: undefined,
  server: { port: 4321 }
});
